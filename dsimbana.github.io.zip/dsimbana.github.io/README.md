# dsimbana.github.io
El siguiente repositorio se trata de un pequeño pero interesante proyecto web.
En esta práctica los alumnos realizarán un ejercicio de consolidación global del curso, consistente en la creación de un sitio web personal en la nube. Para ello utilizarán github para alojar el repositorio con los ficheros y contenidos de la práctica y también como sitio de publicación de su página personal, que podrá consultarse en el siguiente URL:  https://&lt;usuario>.github.io  
Donde &lt;usuario> se deberá sustituir por el nombre elegido por el usuario para la cuenta en github.  Para realizar la práctica, los alumnos deben seguir las instrucciones de los videos del módulo 9 y entregar el URL de la página personal creada.
